ADS.addEvent(window,'load', function() { 
    alert('document.body is a: ' + document.body);
});

ADS.addEvent(window,'load',function() {
    alert('document.getElementById is a: ' + document.getElementById);
});
