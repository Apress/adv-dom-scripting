ADS.addEvent(window,'load',function() {
	var myObject = {};
	var anotherObject = new myObject();
});