//Figure 2-x

ADS.Addevent(window,'load', function() { 
	alert('document.body is a: ' + document.body);
});

//Figure 2-x
ADS.addEvent(window,'load',function() { 
	alert('document.getElementById is a: ' + document.getElementById);
});