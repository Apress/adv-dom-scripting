var sound = 'Roar!';
function myOrneryBeast() {
    this.style.color='green';
    alert(sound);
}
myOrneryBeast();

