function myFunction(message) { alert(message); }

myfunction('Without window object');

window.myfunction('With window object');