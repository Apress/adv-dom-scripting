/* this doesn't really do anything. it is here only for demonstartion. */
var street = '123 Somewhere';
var city = 'Ottawa';
var province = 'Ontario';