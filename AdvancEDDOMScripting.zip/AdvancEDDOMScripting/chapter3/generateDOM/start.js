/* A new namespace for the generator */
(function(){

function encode(str) { }

function checkForVariable(v) { }

function processAttribute(tabCount,refParent) { }

function processNode(tabCount,refParent) { }

var domCode = '';
var nodeNameCounters = [];
var requiredVariables = '';
var newVariables = '';

function generate(strHTML,strRoot) { }

window['generateDOM'] = generate;

})();
