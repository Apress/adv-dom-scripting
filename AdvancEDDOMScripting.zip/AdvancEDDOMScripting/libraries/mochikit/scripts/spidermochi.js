#!/usr/bin/env js -w
load('tests/standalone.js');
