#!/usr/bin/env java -jar scripts/js.jar
load('tests/standalone.js');
