ADS.addEvent(window,'load',function() {

	ADS.addStyleSheet('pink.css','screen');

	ADS.removeStyleSheet('green.css','screen');


});